function registrar()
{
    let usua = document.getElementById("usuario").value;
    let contra = document.getElementById("contraseña").value;


    if("contraseña == contraseña")
    {
        //alert("Contraseña correcta");
        document.getElementById("bienvenida").submit();
    }
    else
    {
        alert("Contraseña incorrecta");
    }
    }
