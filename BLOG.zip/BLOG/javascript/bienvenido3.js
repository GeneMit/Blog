let url = window.location.href;

let nombre = new URLSearchParams(window.location.search).get("nombre");

document.getElementById("bienvenida").innerHTML = nombre;
console.log("Bienvenido usuario"  +  nombre);

    
// Botón de borrar información en el formulario
function borrarForm() {
    document.getElementById("ArticuloForm").reset();}
    
// Botón de envío de formulario a página de bienvenida
function CrearArticulo() {
    var1 = document.getElementById("artic").value;
    var2 = document.getElementById("nomb").value;
    var3 = document.getElementById("resum").value;
    var4 = document.getElementById("aut").value;

var elarticulo = ("Este artículo trata sobre " + var1 + " " + var2 + " " + var3 + " " + var4);
    console.log(elarticulo);


    localStorage.setItem("articulo", elarticulo);

    // Redirigir a la página de visualización de datos
    window.location.href="blog.html";
}
 
        

    