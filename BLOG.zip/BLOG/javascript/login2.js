//Botón de borrar información en el formulario
function limpiar()
{ document.getElementById("logear").reset(); }

//Botón de envio de formulario a pagina de bienvenida

function Iniciar()
{
    let user = document.getElementById("usuario").value;
    let pass = document.getElementById("contraseña").value;    let correct = "252019"; // Cambia esto por tu contraseña correcta como una cadena
    if (pass === correct) {
        // Acceso correcto
        alert("Iniciado con éxito");
        // Envío de formulario si es necesario
        document.getElementById("logear").submit();
    } 
    else {
        // Contraseña incorrecta
        alert("Contraseña incorrecta");
        // Mostrar mensaje de error en un elemento HTML con el ID "error" si existe
        let errorElement = document.getElementById("logear");
        if (errorElement) {
            errorElement.textContent = "Contraseña incorrecta, vuelve a intentar";
        }
        // Limpiar el campo de contraseña
        //document.getElementById("contraseña").value = "";
    }

    // Mostrar en la consola el resultado del inicio de sesión
    console.log("Este es el usuario " + user + " y esta es la contraseña " + pass);

}
    

